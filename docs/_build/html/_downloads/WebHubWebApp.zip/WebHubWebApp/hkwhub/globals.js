var g_serverAPIBaseURL = "http://54.191.162.69:8080/service/api";

/* Foursquare  */
var g_FoursquareAPIVenueSearch = "https://api.foursquare.com/v2/venues/search?";
var g_FoursquareClientId = "UQM1CPZXPY0VQ1C0ZNZWLNROISOA1IMUUQ1DMHPKX3LTPFUX";
var g_FoursquareClientSecret = "JN5IKJXYYYQLXVB2UYDC3ASBC4KOEOA3VI5JVJ0AI1XHXGTM";
var g_FoursquareCategoryIds = "4d4b7105d754a06374d81259"; // Food : it can be a combinatio of multiple categoryIds
var g_FoursqukDistance = 1000;

